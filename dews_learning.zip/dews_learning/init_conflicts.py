import sqlite3
from datetime import datetime
import os

DB_PATH = "Database/dews_core.db"

def init_conflicts_table():
    # اطمینان از وجود پوشه Database
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        # حذف جدول قبلی در صورت ناسازگاری (برای تمیز شدن محیط تستی) یا استفاده از IF NOT EXISTS
        cursor.execute("DROP TABLE IF EXISTS conflicts")
        
        cursor.execute("""
            CREATE TABLE conflicts (
                conflict_id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id_a TEXT,
                event_id_b TEXT,
                target_border TEXT,
                conflict_type TEXT,
                severity REAL,
                description TEXT,
                detected_at TEXT,
                resolved INTEGER DEFAULT 0
            )
        """)
        
        cursor.execute("""
            INSERT INTO conflicts (event_id_a, event_id_b, target_border, conflict_type, severity, description, detected_at, resolved)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "EVT_101", 
            "EVT_102", 
            "Dogharoun", 
            "تعارض اطلاعاتی منابع مرزی", 
            0.80, 
            "ایرنا: تردد عادی در مرز دوغارون / طلوع‌نیوز: انسداد موقت و اعتصاب رانندگان افغان", 
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"), 
            0
        ))
        
        conn.commit()
        print("✅ جدول conflicts با موفقیت ایجاد و داده تستی درج شد!")
    except Exception as e:
        print(f"❌ خطا در ایجاد جدول یا درج داده: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    init_conflicts_table()
