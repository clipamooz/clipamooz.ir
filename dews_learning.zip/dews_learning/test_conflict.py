import sqlite3
from datetime import datetime

DB_PATH = "Database/dews_core.db"

def inject_test_conflict():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # اول جدول قبلی رو پاک می‌کنیم تا ساختارش صد درصد فیکس بشه
    cursor.execute("DROP TABLE IF EXISTS conflicts")
    
    # ساخت جدول جدید با ستون‌های استاندارد
    cursor.execute("""
        CREATE TABLE conflicts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_a TEXT,
            source_b TEXT,
            divergence_score REAL,
            timestamp TEXT,
            status TEXT,
            resolution_notes TEXT
        )
    """)
    
    # درج داده تستی
    test_data = (
        "IRNA_News",
        "ToloNews_Kabul",
        0.85,
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "active",
        "تعارض شدید در گزارش حجم مبادلات مرز دوغارون"
    )
    
    cursor.execute("""
        INSERT INTO conflicts (source_a, source_b, divergence_score, timestamp, status, resolution_notes)
        VALUES (?, ?, ?, ?, ?, ?)
    """, test_data)
    
    conn.commit()
    conn.close()
    print("✅ جدول conflicts ریست شد و تعارض تستی با موفقیت نشست!")

if __name__ == "__main__":
    inject_test_conflict()
