# config.py
"""تنظیمات مرکزی سامانه DEWS."""
import os

# مسیر دقیق ریشه پروژه (dews_learning)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# مسیر پایگاه داده
DB_NAME = os.path.join(BASE_DIR, "Database", "dews_core.db")

# مسیر لاگ‌ها داخل پوشه Outputs/logs
AUDIT_LOG_FILE = os.path.join(BASE_DIR, "Outputs", "logs", "system_audit_log.txt")

# مسیر گزارش تجار داخل پوشه Outputs/reports
MERCHANT_REPORT_FILE = os.path.join(BASE_DIR, "Outputs", "reports", "merchant_report.txt")

# مسیر گزارش‌های شخصی‌سازی‌شده تجار
PERSONALIZED_REPORT_FILE = os.path.join(BASE_DIR, "Outputs", "reports", "personalized_reports.txt")
# مسیر لاگ اصلی سامانه (Outputs/logs/dews.log)
DEWS_LOG_FILE = os.path.join(BASE_DIR, "Outputs", "logs", "dews.log")

# پیش‌فرض‌های مرزی و سوپرفورکستینگ بر اساس پایان‌نامه
DEFAULT_BOUNDARY = "دوغارون / اسلام‌قلعه"
DEFAULT_HYPOTHESIS = "انسداد یا توقف موقت مرز دوغارون ظرف ۴۸ ساعت آینده"
HISTORICAL_BASE_RATE = 0.20  # نرخ پایه ۲۰٪ (Outside View)
DECAY_RATE = 0.03  # نرخ افت زمانی سیگنال
BRIER_GROUND_TRUTH = 1.0  # مقدار حقیقت (مثلا ۱ یعنی مرز بسته شد / باز شد)
HISTORICAL_BASE_RATE = 0.30  # نرخ پایه اولیه (۳۰ درصد)
AUDIT_LOG_FILE = "Outputs/logs/system_audit_log.txt"
PERSONALIZED_REPORT_FILE = "Outputs/reports/personalized_reports.txt"
