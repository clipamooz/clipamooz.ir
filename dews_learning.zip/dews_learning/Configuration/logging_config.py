# logging_config.py
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from logging.handlers import RotatingFileHandler
from datetime import datetime, timezone
import logging
import sys
from Configuration import config



def setup_logger():
      # اطمینان از وجود پوشه لاگ
    os.makedirs(os.path.dirname(config.AUDIT_LOG_FILE), exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - [%(levelname)s] - %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(
                config.AUDIT_LOG_FILE, encoding="utf-8"
            ),  # لاگ فایلی با utf-8 ذخیره بشه
        ],
    )
    return logging.getLogger("DEWS_CORE")


@dataclass(frozen=True)
class LogSettings:
    log_dir: str = os.path.dirname(config.DEWS_LOG_FILE)
    log_file: str = "dews.log"
    max_bytes: int = 2_000_000      # ~2MB
    backup_count: int = 7           # keep last 7 files
    console_level: int = logging.INFO
    file_level: int = logging.INFO
    app_name: str = "DEWS"


class JsonFormatter(logging.Formatter):
    """Structured logs for dashboards/observability."""
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "module": record.module,
            "func": record.funcName,
            "line": record.lineno,
        }

        # attach exception info if present
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)

        # attach extra fields (if provided)
        # common pattern: logger.info("...", extra={"event_id": "...", "merchant_id": 12})
        for k, v in record.__dict__.items():
            if k.startswith("_"):
                continue
            if k in payload:
                continue
            if k in (
                "args", "asctime", "created", "exc_info", "exc_text", "filename",
                "levelno", "lineno", "msecs", "message", "module", "msg",
                "name", "pathname", "process", "processName", "relativeCreated",
                "stack_info", "thread", "threadName", "funcName"
            ):
                continue
            payload[k] = v

        return json.dumps(payload, ensure_ascii=False)


_configured = False


def setup_logging(settings: LogSettings | None = None) -> None:
    """Call once at app startup (main.py)."""
    global _configured
    if _configured:
        return

    settings = settings or LogSettings()
    os.makedirs(settings.log_dir, exist_ok=True)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)  # handlers decide what to emit

    # Console handler (human-friendly)
    ch = logging.StreamHandler()
    ch.setLevel(settings.console_level)
    ch_formatter = logging.Formatter(
        fmt="%(levelname)s | %(name)s | %(message)s"
    )
    ch.setFormatter(ch_formatter)

    # File handler (structured + rotating)
    fh = RotatingFileHandler(
        filename=os.path.join(settings.log_dir, settings.log_file),
        maxBytes=settings.max_bytes,
        backupCount=settings.backup_count,
        encoding="utf-8",
    )
    fh.setLevel(settings.file_level)
    fh.setFormatter(JsonFormatter())

    root.addHandler(ch)
    root.addHandler(fh)

    _configured = True


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
