# Database/seed_base_rates.py
import sys
import os
import sqlite3

# تنظیم مسیر برای دسترسی به کانفیگ
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import Configuration.config as config
from Configuration.logging_config import get_logger

logger = get_logger("DEWS.BaseRatesSeed")

BASE_RATES_DATA = [
    (
        "BR_DOGHAROUN_CLOSURE",
        "BORDER_CLOSURE",
        "Dogharoun",
        0.28,
        "تنش‌های سیاسی/امنیتی منجر به توقف کامل مرز اسلام‌قلعه-دوغارون در بازه ده‌ساله",
        "1394-1404"
    ),
    (
        "BR_MILAK_CLOSURE",
        "BORDER_CLOSURE",
        "Milak",
        0.35,
        "بحران‌های آبی حقابه هیرمند و تنش‌های مرزی سیستان منجر به توقف کامیون‌ها",
        "1396-1404"
    ),
    (
        "BR_MAHIROOD_CLOSURE",
        "BORDER_CLOSURE",
        "Mahirood",
        0.18,
        "نرخ پایه توقف تجاری در مرز ماهیرود (پایدارترین گذرگاه تجاری جنوب خراسان)",
        "1395-1404"
    ),
    (
        "BR_DOGHAROUN_FOOD_DELAY",
        "CUSTOMS_DELAY_FOOD",
        "Dogharoun",
        0.25,
        "معطلی بیش از ۷ روز مواد غذایی و کشاورزی به دلیل تشریفات استاندارد/قرنطینه و TTAC",
        "1400-1404"
    ),
    (
        "BR_TALIBAN_TARIFF_SHOCK",
        "TARIFF_SHOCK",
        "ALL_BORDERS",
        0.42,
        "احتمال صدور بخشنامه‌های تعرفه‌ای ناگهانی وزارت مالیه کابل بدون هماهنگی قبلی",
        "1400-1404"
    )
]

def seed_base_rates():
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    
    # ساخت جدول اگر هنوز ساخته نشده
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS base_rates (
        rate_id TEXT PRIMARY KEY,
        category TEXT NOT NULL,
        target_border TEXT NOT NULL,
        prior_probability REAL NOT NULL,
        reference_class TEXT,
        sample_period TEXT,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    
    for row in BASE_RATES_DATA:
        cursor.execute("""
        INSERT OR REPLACE INTO base_rates 
        (rate_id, category, target_border, prior_probability, reference_class, sample_period)
        VALUES (?, ?, ?, ?, ?, ?)
        """, row)
        
    conn.commit()
    conn.close()
    logger.info("✅ داده‌های نرخ پایه بر اساس پایان‌نامه با موفقیت در دیتابیس تزریق شد.")
    print("Base rates seeded successfully into DEWS Database.")

if __name__ == "__main__":
    seed_base_rates()
