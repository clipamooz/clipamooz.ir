import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "dews_core.db")

def init_db():
    print(f"در حال اتصال و راه‌اندازی دیتابیس در مسیر: {DB_PATH}")
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    try:
        # جدول رویدادها (Events)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                event_id TEXT PRIMARY KEY,
                source_name TEXT NOT NULL,
                raw_text TEXT NOT NULL,
                source_credibility REAL NOT NULL,
                timestamp TEXT NOT NULL,
                content_hash TEXT UNIQUE,
                published_at DATETIME
            )
        ''')

        # جدول سیگنال‌ها (Signals)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS signals (
                signal_id TEXT PRIMARY KEY,
                event_id TEXT NOT NULL,
                target_border TEXT NOT NULL,
                likelihood_ratio REAL NOT NULL,
                time_decay_lambda REAL NOT NULL,
                hours_passed REAL NOT NULL,
                FOREIGN KEY (event_id) REFERENCES events (event_id)
            )
        ''')

        # جدول پیش‌بینی‌ها (Forecasts)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS forecasts (
                forecast_id TEXT PRIMARY KEY,
                signal_id TEXT NOT NULL,
                prior_probability REAL NOT NULL,
                posterior_probability REAL NOT NULL,
                brier_score REAL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (signal_id) REFERENCES signals (signal_id)
            )
        ''')

        # جدول نرخ‌های پایه (Base Rates)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS base_rates (
                rate_id TEXT PRIMARY KEY,
                category TEXT NOT NULL,
                target_border TEXT NOT NULL,
                prior_probability REAL NOT NULL,
                reference_class TEXT,
                sample_period TEXT,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        conn.commit()
        print("✅ تمامی جداول پایگاه داده DEWS با موفقیت ایجاد شدند.")

    except Exception as e:
        conn.rollback()
        print(f"🔴 خطا در اولیه‌سازی دیتابیس: {e}")
        raise
    finally:
        conn.close()

if __name__ == "__main__":
    init_db()
