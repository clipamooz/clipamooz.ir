"""
DEWS System - Module: Warning Questions Migration & Seeding
پیاده‌سازی جدول پرسش‌های هشدار و تزریق نرخ‌های پایه اولیه
"""

import sqlite3
from datetime import datetime, timedelta

import os

# مسیر قطعی دیتابیس اصلی پروژه:
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_NAME = os.path.join(BASE_DIR, "Database", "dews_core.db")



def init_warning_questions():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    # ایجاد جدول پرسش‌های هشدار استاندارد
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS warning_questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cluster TEXT NOT NULL,              -- حوزه: لجستیک مرزی، گمرک و تعرفه، تسویه ارزی، امنیت
        target_entity TEXT NOT NULL,        -- هدف: دوغارون، میلک، هرات، سرای شهزاده و...
        question_text TEXT NOT NULL,        -- متن دقیق، شفاف و ابطال‌پذیر سوال
        time_horizon_days INTEGER NOT NULL, -- افق زمانی پیش‌بینی به روز
        created_at TEXT NOT NULL,           -- تاریخ ایجاد سوال
        expiry_date TEXT NOT NULL,          -- تاریخ انقضا و تسویه پیش‌بینی
        base_rate REAL NOT NULL,            -- نرخ پایه تاریخی (Base Rate)
        current_probability REAL NOT NULL,  -- احتمال جاری (به‌روزرسانی شونده توسط بیزین)
        status TEXT DEFAULT 'ACTIVE',       -- وضعیت: ACTIVE, RESOLVED, EXPIRED
        resolution_criteria TEXT            -- معیار شفاف تسویه (طبق اصول تتلاک)
    );
    """)

    # پرسش‌های هشدار نمونه مبتنی بر مسائل واقعی ایران-افغانستان
    sample_questions = [
        (
            "لجستیک مرزی",
            "Dogharoun",
            "آیا مرز تجاری دوغارون طی ۳۰ روز آینده با توقف تردد بیش از ۲۴ ساعت روبه‌رو خواهد شد؟",
            30,
            0.18,  # نرخ پایه تاریخی سالانه (تقریباً ۱۸ درصد ماه‌ها اختلال جدی داشتند)
            0.18,
            "توقف ثبت سامانه جامع یا صف بیش از ۵۰۰ کامیون اعلام شده توسط مراجع رسمی مرزبانی/گمرک"
        ),
        (
            "گمرک و تعرفه",
            "Islam_Qala",
            "آیا گمرک اسلام‌قلعه ظرف ۱۵ روز آینده تعرفه ورود کالاهای نفتی/پتروشیمی را افزایش می‌دهد؟",
            15,
            0.12,  # نرخ پایه تغییرات ناگهانی بخشنامه‌های طالبان
            0.12,
            "ابلاغ بخشنامه رسمی جدید توسط وزارت مالیه طالبان مبنی بر افزایش حقوق ورودی"
        ),
        (
            "تسویه مالی و ارز",
            "Herat_Hawala",
            "آیا کارمزد انتقال حواله در بازار سرای شهزاده هرات طی ۷ روز آینده بیش از ۱۰ درصد جهش خواهد داشت؟",
            7,
            0.08,  # نرخ پایه نوسانات کارمزد حواله‌داری
            0.08,
            "گزارش صرافی‌های معتبر هرات مبنی بر رشد کارمزد حواله تومان/افغانی به بیش از ۱۰ درصد میانگین هفته قبل"
        ),
        (
            "لجستیک مرزی",
            "Milak",
            "آیا محور ترانزیتی مرز میلک (سیستان و بلوچستان) ظرف ۲۰ روز آینده دچار انسداد فیزیکی خواهد شد؟",
            20,
            0.10,
            0.10,
            "بسته شدن پل ابریشم یا ممانعت نیروهای مرزی طرفین از ورود و خروج کامیون‌ها به مدت بیش از ۱۲ ساعت"
        )
    ]

    now = datetime.now()

    for item in sample_questions:
        cluster, entity, q_text, horizon, b_rate, c_prob, criteria = item
        created_str = now.strftime("%Y-%m-%d %H:%M:%S")
        expiry_str = (now + timedelta(days=horizon)).strftime("%Y-%m-%d %H:%M:%S")

        # بررسی برای جلوگیری از ثبت تکراری در صورت اجرای چندباره
        cursor.execute("SELECT id FROM warning_questions WHERE question_text = ?", (q_text,))
        exists = cursor.fetchone()

        if not exists:
            cursor.execute("""
            INSERT INTO warning_questions (
                cluster, target_entity, question_text, time_horizon_days,
                created_at, expiry_date, base_rate, current_probability, status, resolution_criteria
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?)
            """, (cluster, entity, q_text, horizon, created_str, expiry_str, b_rate, c_prob, criteria))

    conn.commit()
    conn.close()
    print("✅ جدول warning_questions با موفقیت ایجاد شد و پرسش‌های هشدار اولیه ثبت شدند.")

if __name__ == "__main__":
    init_warning_questions()
