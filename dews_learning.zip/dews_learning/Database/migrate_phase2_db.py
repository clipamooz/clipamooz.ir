# migrate_phase2_db.py
"""
DEWS Phase 2 - Database Migration Script
ارتقای اسکیمای پایگاه‌داده برای پشتیبانی از Ingestion زنده و ماژول ۶۲
"""
import sqlite3
from pathlib import Path

DB_PATH = Path("Database/dews_core.db")

def upgrade_schema():
    if not DB_PATH.exists():
        print(f"⚠️ پایگاه‌داده در مسیر {DB_PATH} یافت نشد. لطفاً ابتدا دیتابیس را بررسی کنید.")
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    print("🚀 در حال به‌روزرسانی اسکیمای دیتابیس برای فاز ۲...")

    # ۱. افزودن ستون‌های هش محتوا و تاریخ انتشار به جدول events (در صورت عدم وجود)
    cursor.execute("PRAGMA table_info(events);")
    columns = [col[1] for col in cursor.fetchall()]

    if "content_hash" not in columns:
        cursor.execute("ALTER TABLE events ADD COLUMN content_hash TEXT;")
        cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_events_hash ON events(content_hash);")
        print("✅ ستون content_hash (جهت حذف تکرار / Deduplication) اضافه شد.")

    if "published_at" not in columns:
        cursor.execute("ALTER TABLE events ADD COLUMN published_at DATETIME;")
        print("✅ ستون published_at (زمان انتشار خبر در مبدأ) اضافه شد.")

    # ۲. ساخت جدول sources برای اعتبارسنجی منابع (رسمی، تلگرامی، تاجر میدانی)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sources (
        source_id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_name TEXT UNIQUE NOT NULL,
        channel_type TEXT NOT NULL,       -- 'official_media', 'telegram_pulse', 'trusted_trader'
        base_reliability REAL NOT NULL,   -- ضریب بین 0.1 تا 1.0
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)
    print("✅ جدول sources (اعتبارسنجی منبع) ایجاد گردید.")

    # ثبت چند منبع پیش‌فرض برای تست
    default_sources = [
        ('IRNA', 'official_media', 0.90, 'خبرگزاری رسمی جمهوری اسلامی ایران'),
        ('TOLOnews', 'official_media', 0.85, 'طلوع‌نیوز افغانستان'),
        ('Herat_Sarai_Telegram', 'telegram_pulse', 0.45, 'کانال‌های غیررسمی نبض بازار هرات'),
        ('Khorasan_Drivers_Union', 'telegram_pulse', 0.60, 'کانال صنفی رانندگان ترانزیت'),
        ('Verified_Afghan_Trader', 'trusted_trader', 0.80, 'تاجران معتمد و ارزیابی‌های میدانی')
    ]
    cursor.executemany("""
    INSERT OR IGNORE INTO sources (source_name, channel_type, base_reliability, description)
    VALUES (?, ?, ?, ?);
    """, default_sources)
    # ایجاد جدول تناقضات و مغایرت‌های منابع (Conflict Alert)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS conflicts (
        conflict_id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id_a TEXT,
        event_id_b TEXT,
        conflict_type TEXT NOT NULL,       -- نوع مغایرت مثل 'BORDER_STATUS_CONTRADICTION'
        severity REAL DEFAULT 0.5,         -- شدت تناقض بین 0.0 تا 1.0
        description TEXT,
        resolved INTEGER DEFAULT 0,        -- 0 = فعال/حل‌نشده، 1 = حل‌شده
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    """)
    print("✅ جدول conflicts (تشخیص مغایرت منابع) ایجاد گردید.")

    conn.commit()
    conn.close()
    print("🎉 مهاجرت اسکیمای فاز ۲ با موفقیت انجام شد!")

if __name__ == "__main__":
    upgrade_schema()
