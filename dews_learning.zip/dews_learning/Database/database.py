import sqlite3
import os
import sys

# اضافه کردن ریشه پروژه به مسیرهای پایتون
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from datetime import datetime
import Configuration.config as config
from Configuration.logging_config import get_logger


logger = get_logger("DEWS.Database")

def get_db_connection():
    return sqlite3.connect(config.DB_NAME)

def save_event(event_id, source_name=None, raw_text=None, source_credibility=None, timestamp=None, **kwargs):
    # پشتیبانی همزمان از هر دو نام source و source_name
    actual_source = source_name or kwargs.get('source', 'Unknown')
    actual_text = raw_text or kwargs.get('raw_text', '')
    actual_cred = source_credibility if source_credibility is not None else kwargs.get('credibility', kwargs.get('source_credibility', 0.5))
    actual_time = timestamp or kwargs.get('timestamp')

    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            if actual_time:
                cursor.execute(
                    "INSERT OR REPLACE INTO events (event_id, source_name, raw_text, source_credibility, timestamp) VALUES (?, ?, ?, ?, ?)",
                    (event_id, actual_source, actual_text, actual_cred, actual_time)
                )
            else:
                cursor.execute(
                    "INSERT OR REPLACE INTO events (event_id, source_name, raw_text, source_credibility) VALUES (?, ?, ?, ?)",
                    (event_id, actual_source, actual_text, actual_cred)
                )
            conn.commit()
            logger.info(f"Event saved: {event_id}")
    except Exception as e:
        logger.error(f"Error saving event {event_id}: {e}")
        raise

def save_signal(signal_id=None, event_id=None, border=None, signal_type=None, likelihood_ratio=None, hours_passed=0, **kwargs):
    # دریافت و نگاشت هوشمند متغیرها چه با نام قدیمی چه جدید
    actual_sig_id = signal_id or kwargs.get('sig_id')
    actual_event_id = event_id or kwargs.get('event_id')
    # پشتیبانی از boundary, border یا target_border
    actual_border = border or kwargs.get('target_border') or kwargs.get('boundary') or kwargs.get('border_name', 'Dogharoun')
    actual_type = signal_type or kwargs.get('indicator_type') or kwargs.get('type', 'customs_delay')
    actual_lr = likelihood_ratio if likelihood_ratio is not None else kwargs.get('lr', 1.0)
    actual_hours = hours_passed if hours_passed is not None else kwargs.get('hours', 0)

    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            
            # درج مستقیم و دقیق در جدول signals با ستون‌های استاندارد init_dews_db.py
            cursor.execute(
                """
                INSERT OR REPLACE INTO signals 
                (signal_id, event_id, target_border, indicator_type, likelihood_ratio, hours_passed) 
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (actual_sig_id, actual_event_id, actual_border, actual_type, actual_lr, actual_hours)
            )
            conn.commit()
            logger.info(f"Signal saved: {actual_sig_id} for border: {actual_border}")
    except Exception as e:
        logger.error(f"Error saving signal {actual_sig_id}: {e}")
        raise

def save_forecast(forecast_id=None, signal_id=None, hypothesis=None, prior=None, posterior=None, brier_score=None, **kwargs):
    actual_f_id = forecast_id or kwargs.get('forecast_id')
    actual_sig_id = signal_id or kwargs.get('signal_id')
    actual_hypo = hypothesis or kwargs.get('hypothesis', 'Border Disruption Risk')
    actual_prior = prior if prior is not None else kwargs.get('prior_base_rate', kwargs.get('base_rate', 0.20))
    actual_posterior = posterior if posterior is not None else kwargs.get('posterior_probability', kwargs.get('posterior_prob', 0.50))
    actual_brier = brier_score if brier_score is not None else kwargs.get('brier', 0.0)
    actual_outcome = kwargs.get('actual_outcome', None)
    actual_created_at = kwargs.get('created_at') or kwargs.get('timestamp') or datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT OR REPLACE INTO forecasts 
                (forecast_id, signal_id, hypothesis, prior_base_rate, posterior_probability, actual_outcome, brier_score, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (actual_f_id, actual_sig_id, actual_hypo, actual_prior, actual_posterior, actual_outcome, actual_brier, actual_created_at)
            )
            conn.commit()
            logger.info(f"Forecast saved: {actual_f_id}")
    except Exception as e:
        logger.error(f"Error saving forecast {actual_f_id}: {e}")
        raise

def get_base_rate(target_border: str = "Dogharoun", category: str = "BORDER_CLOSURE", default: float = 0.25) -> float:
    """
    بازیابی نرخ پایه (Prior Probability / Outside View) از جدول base_rates
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = """
            SELECT prior_probability 
            FROM base_rates 
            WHERE LOWER(target_border) = LOWER(?) AND LOWER(category) = LOWER(?)
            ORDER BY last_updated DESC 
            LIMIT 1
        """
        cursor.execute(query, (target_border, category))
        row = cursor.fetchone()
        conn.close()
        
        if row and row[0] is not None:
            logger.info(f"📊 نرخ پایه برای مرز {target_border} ({category}) دریافت شد: {row[0]}")
            return float(row[0])
        else:
            logger.warning(f"⚠️ نرخ پایه‌ای برای {target_border} یافت نشد؛ بازگشت به پیش‌فرض: {default}")
            return default
            
    except Exception as e:
        logger.error(f"❌ خطا در بازیابی نرخ پایه: {e}؛ بازگشت به پیش‌فرض: {default}")
        return default


class DatabaseManager:
    """Wrapper class to provide object-oriented database interface for DEWS modules."""
    def __init__(self, db_name=None):
        self.db_name = db_name or getattr(config, 'DB_NAME', 'dews.db')

    def get_connection(self):
        return sqlite3.connect(self.db_name)

    def save_event(self, *args, **kwargs):
        return save_event(*args, **kwargs)

    def save_signal(self, *args, **kwargs):
        return save_signal(*args, **kwargs)

    def save_forecast(self, *args, **kwargs):
        return save_forecast(*args, **kwargs)

    def get_active_warning_questions(self, target_border: str = None):
        """واکشی پرسش‌های فعال هشدار از جدول بر اساس اسکیمای واقعی"""
        conn = self.get_connection()
        cursor = conn.cursor()
        if target_border:
            cursor.execute(
                "SELECT * FROM warning_questions WHERE status = 'ACTIVE' AND target_entity = ?",
                (target_border,),
            )
        else:
            cursor.execute("SELECT * FROM warning_questions WHERE status = 'ACTIVE'")
        rows = cursor.fetchall()
        conn.close()
        return rows

    def update_question_probability(self, question_id: int, new_probability: float):
        """به‌روزرسانی آخرین احتمال محاسبه‌شده برای یک پرسش هشدار"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE warning_questions SET current_probability = ? WHERE id = ?",
            (new_probability, question_id),
        )
    
        conn.commit()
        conn.close()
def save_conflict(event_id_a: str, event_id_b: str, conflict_type: str, severity: float, description: str, target_border: str = "Dogharoun"):
    """ثبت تعارض شناسایی‌شده بین دو خبر/منبع در دیتابیس"""
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO conflicts (event_id_a, event_id_b, target_border, conflict_type, severity, description)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (event_id_a, event_id_b, target_border, conflict_type, severity, description))
            conn.commit()
            logger.warning(f"⚠️ تعارض ثبت شد: {description} (شدت: {severity})")
    except Exception as e:
        logger.error(f"❌ خطا در ثبت تعارض: {e}")

def get_active_conflicts(target_border: str = "Dogharoun"):
    """واکشی تعارض‌های حل‌نشده جهت نمایش در گزارش بازرگان"""
    try:
        with get_db_connection() as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT conflict_id, conflict_type, severity, description, detected_at
                FROM conflicts
                WHERE resolved = 0 AND (target_border = ? OR target_border IS NULL)
                ORDER BY detected_at DESC
            """, (target_border,))
            return cursor.fetchall()
    except Exception as e:
        logger.error(f"❌ خطا در خواندن تعارض‌ها: {e}")
        return []

