# Modules/ingestion/ingestion_service.py
"""
DEWS Phase 2 - Ingestion Service
مدیریت دریافت، اعتبارسنجی منابع و فیلتر ضدتکرار (Deduplication & Credibility Engine)
"""
import sqlite3
import hashlib
from datetime import datetime, timezone
from pathlib import Path
from Configuration.logging_config import get_logger

logger = get_logger("IngestionService")


class IngestionService:
    def __init__(self, db_path=Path("Database/dews_core.db")):
        self.db_path = db_path

    def _generate_hash(self, text: str) -> str:
        """تولید هش یکتا برای جلوگیری از ورود رویدادهای تکراری (Garbage In / Duplication)"""
        clean_text = "".join(text.lower().split())
        return hashlib.sha256(clean_text.encode('utf-8')).hexdigest()

    def get_source_info(self, source_name: str) -> dict:
        """استعلام ضریب اعتبار منبع از جدول sources دیتابیس"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT base_reliability FROM sources WHERE source_name = ?", (source_name,))
            row = cursor.fetchone()
            conn.close()
            if row:
                return {"base_reliability": float(row[0])}
        except Exception as e:
            logger.error(f"Error fetching source info for {source_name}: {e}")
        return {"base_reliability": 0.5}

    def detect_and_record_conflict(self, cursor, current_event_id, current_text, source_name):
        """
        بررسی مغایرت معنایی خبر جدید با رویدادهای ۲۴ ساعت گذشته
        مثلاً تناقض بین ادعای «باز بودن» و «انسداد/توقف کامل» گذرگاه
        """
        # واکشی رویدادهای ۲۴ ساعت گذشته (غیر از خود خبر جدید)
        cursor.execute("""
            SELECT event_id, raw_text, source_name 
            FROM events 
            WHERE event_id != ? 
              AND datetime(timestamp) >= datetime('now', '-1 day')
        """, (current_event_id,))
        
        recent_events = cursor.fetchall()
        
        # کلیدواژه‌های ساده برای تشخیص تناقض فاحش وضعیت مرز
        closure_keywords = ["مسدود", "انسداد", "بسته", "توقف کامل", "اعتصاب"]
        open_keywords = ["باز", "روان", "تردد عادی", "بدون مشکل"]
        
        current_is_closure = any(kw in current_text for kw in closure_keywords)
        current_is_open = any(kw in current_text for kw in open_keywords)
        
        if not current_is_closure and not current_is_open:
            return # اگر خبر ربطی به وضعیت باز/بسته نداشت، از بررسی عبور کن

        for ev_id, ev_text, ev_source in recent_events:
            ev_is_closure = any(kw in ev_text for kw in closure_keywords)
            ev_is_open = any(kw in ev_text for kw in open_keywords)
            
            # اگر خبر جدید از انسداد می‌گوید اما خبر قبلی از باز بودن (یا برعکس)
            if (current_is_closure and ev_is_open) or (current_is_open and ev_is_closure):
                conflict_desc = f"تناقض بین منبع '{source_name}' و '{ev_source}': یکی از باز بودن و دیگری از انسداد مرز می‌گوید."
                
                cursor.execute("""
                    INSERT INTO conflicts (event_id_a, event_id_b, conflict_type, severity, description)
                    VALUES (?, ?, ?, ?, ?)
                """, (current_event_id, ev_id, 'BORDER_STATUS_CONTRADICTION', 0.8, conflict_desc))
                
                print(f"⚠️ [Conflict Alert Detected] {conflict_desc}")
                break # هر خبر حداقل با اولین تناقض بارز ثبت می‌شود

    def ingest_event(self, event_data: dict) -> dict:
        """دریافت دیکشنری رویداد، اعتبارسنجی، بررسی تکراری نبودن و ثبت در دیتابیس"""
        raw_text = event_data.get("description", "")
        source_name = event_data.get("source_type", "unknown")
        published_at = event_data.get("published_at", datetime.now(timezone.utc).isoformat())
        
        if source_name in ["trusted_expert", "Verified_Afghan_Trader"]:
            credibility = 0.95
        else:
            source_info = self.get_source_info(source_name)
            credibility = source_info["base_reliability"]

        content_hash = self._generate_hash(raw_text)

        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("SELECT event_id FROM events WHERE content_hash = ?", (content_hash,))
            if cursor.fetchone():
                conn.close()
                return None

            cursor.execute("""
                INSERT INTO events (
                    event_id, source_name, raw_text, source_credibility, 
                    timestamp, content_hash, published_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                f"evt_{content_hash[:12]}",
                source_name,
                raw_text,
                credibility,
                datetime.now(timezone.utc).isoformat(),
                content_hash,
                published_at
            ))
            
            # دریافت ID رویداد تازه ثبت شده
            current_event_id = cursor.lastrowid
            
            # بررسی و ثبت مغایرت احتمالی با اخبار گذشته
            self.detect_and_record_conflict(cursor, current_event_id, raw_text, source_name)
            conn.commit() # کامیت نهایی شامل conflicts
            
            status = "inserted"
            print(f"✅ رویداد جدید با موفقیت ثبت شد: [{source_name}] {raw_text[:40]}...")

            
            conn.close()
            
            event_data["source_credibility"] = credibility
            return event_data

        except Exception as e:
            logger.error(f"Ingestion database error: {e}")
            return None

    def batch_ingest(self, events_list: list) -> list:
        """پردازش دسته‌ای رویدادها برای پایپ‌لاین"""
        cleaned_events = []
        for ev in events_list:
            res = self.ingest_event(ev)
            if res:
                cleaned_events.append(res)
        return cleaned_events
