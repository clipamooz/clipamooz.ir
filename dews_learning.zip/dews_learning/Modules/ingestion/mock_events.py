# Simulated incoming event stream from intelligence monitors
stream_events = [
    {
        "source": "IRNA / Dogharoun Border Customs",
        "credibility": 0.85,
        "text": "توقف پذیرش کامیون‌ها در اسلام‌قلعه و ایجاد صف‌های سنگین مرزی",
        "boundary": "Dogharoun",
        "indicator": "Customs Stoppage",
        "raw_lr": 3.50,
        "decay_lambda": 0.05,
        "hours_passed": 2.0,
    },
    {
        "source": "Herat Chamber of Commerce Telegram Channel",
        "credibility": 0.75,
        "text": "خطای ۵۰۳ و قطعی زیرسامانه صدور بیجک در گمرک دوغارون",
        "boundary": "Dogharoun",
        "indicator": "Technical Infrastructure Failure",
        "raw_lr": 2.80,
        "decay_lambda": 0.08,
        "hours_passed": 1.0,
    },
    {
        "source": "Afghan Border Commissariat Official Statement",
        "credibility": 0.90,
        "text": "بازگشایی دو گیت اضطراری و آغاز تخلیه بار کامیون‌های متوقف‌شده",
        "boundary": "Dogharoun",
        "indicator": "Diplomatic Coordination",
        "raw_lr": 0.40,
        "decay_lambda": 0.04,
        "hours_passed": 0.5,
    },
]
