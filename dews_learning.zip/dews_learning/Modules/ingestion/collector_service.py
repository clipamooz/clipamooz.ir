# Modules/ingestion/collector_service.py
"""
DEWS Phase 2 - Multi-Channel Data Collector
جمع‌آوری و استانداردسازی داده‌ها از ۳ کانال اصلی:
۱. رسانه‌های رسمی (RSS / News)
۲. کانال‌های نبض بازار و رانندگان (Telegram / Market Sentiment)
۳. مشاهدات میدانی تاجران و خبرگان (Expert & Trader Portal)
"""
from datetime import datetime, timezone
from typing import List, Dict, Any


class TriChannelCollector:
    """گردآورنده چندکاناله جهت تجمیع و استانداردسازی ورودی‌های DEWS"""

    @staticmethod
    def collect_official_news(headline: str, content: str, source_name: str = "official_news") -> Dict[str, Any]:
        """کانال ۱: جمع‌آوری اخبار رسمی دیپلماتیک و دولتی"""
        return {
            "title": headline,
            "source_type": source_name,
            "description": content,
            "category": "diplomatic_statement",
            "base_lr": 1.8,
            "published_at": datetime.now(timezone.utc).isoformat()
        }

    @staticmethod
    def collect_market_telegram(post_text: str, channel_name: str = "telegram_drivers_union") -> Dict[str, Any]:
        """کانال ۲: جمع‌آوری داده‌های غیررسمی رانندگان، صرافی‌ها و بازار هرات/مشهد"""
        return {
            "title": f"گزارش نبض بازار: {post_text[:25]}...",
            "source_type": "market_chatter",
            "description": post_text,
            "category": "border_incident" if any(w in post_text for w in ["صف", "توقف", "مرز", "گمرک"]) else "currency_fluctuation",
            "base_lr": 1.4,
            "published_at": datetime.now(timezone.utc).isoformat()
        }

    @staticmethod
    def collect_trader_observation(trader_name: str, observation: str, delay_hours: float, border_name: str = "دوغارون") -> Dict[str, Any]:
        """کانال ۳: ثبت مستقیم مشاهدات تاجر کف میدان (الهام گرفته از پایان‌نامه)"""
        return {
            "title": f"مشاهده میدانی تاجر ({trader_name}) - {border_name}",
            "source_type": "trusted_expert",
            "description": f"گزارش تاجر: {observation} | تخمین توقف: {delay_hours} ساعت در مرز {border_name}",
            "category": "border_incident",
            "base_lr": 2.8,  # تأثیر بالا به دلیل حضور در صحنه
            "published_at": datetime.now(timezone.utc).isoformat()
        }
