# Modules/ingestion/trader_portal.py
"""
DEWS Phase 2 - Expert & Trader Interactive Portal (English CLI)
Interactive field observation portal for Afghan & Iranian border merchants.
"""
import sys
import os
from datetime import datetime, timezone

# Ensure project root is in sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from Database.database import DatabaseManager
from Modules.ingestion.collector_service import TriChannelCollector
from Modules.ingestion.ingestion_service import IngestionService
from Configuration.logging_config import get_logger

logger = get_logger("TraderPortal")


def submit_trader_report(trader_name: str, border_name: str, delay_hours: float, observation_text: str):
    """Submits trader observation into DEWS Phase 2 Ingestion pipeline."""
    collector = TriChannelCollector()
    ingestion = IngestionService()

    # 1. Format raw event via Channel 3 (Expert / Trader)
    raw_event = collector.collect_trader_observation(
        trader_name=trader_name,
        observation=observation_text,
        delay_hours=delay_hours,
        border_name=border_name
    )

    # 2. Ingestion validation, duplication filter & DB insertion
    clean_event = ingestion.ingest_event(raw_event)
    if not clean_event:
        print("\n[WARNING] Event rejected: duplicate or invalid data!")
        return

    print("\n" + "=" * 60)
    print(" [SUCCESS] Observation recorded successfully!")
    print(f" Border: {border_name} | Delay: {delay_hours} hrs")
    print(f" Credibility Score: {clean_event['source_credibility']}")
    print(" Connected to Bayesian Forecasting Pipeline.")
    print("=" * 60 + "\n")


def interactive_cli():
    """Clean interactive terminal prompt for merchants & field observers."""
    print("\n" + "=" * 60)
    print("      DEWS SYSTEM - TRADER FIELD REPORT PORTAL")
    print("=" * 60)
    
    trader_name = input("Merchant / Observer ID (default: Trusted_Trader_Herat): ").strip() or "Trusted_Trader_Herat"
    border_name = input("Border Point (Dogharoun / IslamQala / Sarakhs) [Dogharoun]: ").strip() or "Dogharoun"
    
    delay_input = input("Estimated Border Delay in Hours (e.g. 12): ").strip() or "0"
    try:
        delay = float(delay_input)
    except ValueError:
        delay = 0.0

    obs = input("Field Observation / Reason (e.g. Customs weight-scale congestion): ").strip() or "Severe customs scale bottleneck observed"

    submit_trader_report(trader_name, border_name, delay, obs)


if __name__ == "__main__":
    interactive_cli()
