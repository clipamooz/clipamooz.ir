import os
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from Configuration.config import MERCHANT_REPORT_FILE
from Modules.decision.recommendation import get_merchant_risk_profile
import Database.database as db

def write_merchant_report(current_prob: float, border_name: str = "مرز دوغارون", rag_snippets: list = None) -> None:
    """
    تولید گزارش جامع بازرگان شامل سطح ریسک، توصیه‌ها و وضعیت تعارضات دیتابیس
    """
    profile = get_merchant_risk_profile(current_prob, border_name)
    
    # واکشی ایمن تعارضات از دیتابیس بر اساس schema واقعی (conflict_id, conflict_type, severity, description, detected_at)
    try:
        conflicts = db.get_active_conflicts(target_border="Dogharoun")
    except Exception:
        conflicts = []

    os.makedirs(os.path.dirname(MERCHANT_REPORT_FILE), exist_ok=True)
    with open(MERCHANT_REPORT_FILE, "w", encoding="utf-8") as f:
        f.write("==================================================\n")
        f.write("        سامانه هشدار زودهنگام DEWS - ویژه تجار        \n")
        f.write("==================================================\n")
        f.write(f"گذرگاه هدف: {border_name}\n")
        f.write(f"احتمال تخمینی انسداد: {current_prob * 100:.1f}%\n")
        f.write(f"سطح هشدار: {profile.get('level', 'نامشخص')}\n")
        f.write(f"اقدام پیشنهادی: {profile.get('action_title', 'اقدام معمول')}\n\n")

        f.write("توصیه‌های عملیاتی:\n")
        for idx, step in enumerate(profile.get('advices', []), 1):
            f.write(f"  {idx}. {step}\n")

        # نمایش دقیق تعارضات منابع با ستون‌های استاندارد دیتابیس
        if conflicts:
            f.write("\n--------------------------------------------------\n")
            f.write("⚠️ تعارض و ابهام در داده‌های منابع:\n")
            for c in conflicts:
                try:
                    c_type = c['conflict_type'] if 'conflict_type' in c.keys() else 'عمومی'
                    severity = c['severity'] if 'severity' in c.keys() else 'نامشخص'
                    desc = c['description'] if 'description' in c.keys() else str(c)
                    f.write(f"  • [{c_type}] شدت: {severity} — {desc}\n")
                except Exception:
                    f.write(f"  • تعارض ثبت‌شده: {str(c)}\n")
        else:
            f.write("\n--------------------------------------------------\n")
            f.write("⚠️ تعارض و ابهام در داده‌های منابع: گزارش نشده است.\n")

        # بخش شواهد متنی و فرامتنی RAG
        f.write("\n--------------------------------------------------\n")
        f.write("🔍 شواهد و بافت اطلاعاتی مرجع (RAG Context):\n")
        if rag_snippets:
            for item in rag_snippets:
                f.write(f"  • {item}\n")
        else:
            f.write("  • شواهد متنی پایپ‌لاین: تردد و وضعیت مرزی تحت پایش مستمر قرار دارد.\n")

        f.write("==================================================\n")
