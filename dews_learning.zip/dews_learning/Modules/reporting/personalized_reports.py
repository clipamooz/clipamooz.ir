# -*- coding: utf-8 -*-
"""
ماژول تولید گزارش‌های شخصی‌سازی‌شده برای تجار مرزی DEWS
"""

import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
from Configuration.logging_config import get_logger

logger = get_logger("DEWS.PersonalizedReports")


def generate_personalized_reports(forecast_probability, output_filepath):
    """
    تولید گزارش متنی راهبردی برای فعالان اقتصادی مرزی بر اساس احتمال نهایی تنش.
    """
    try:
        os.makedirs(os.path.dirname(output_filepath), exist_ok=True)
        
        risk_level = "بالا" if forecast_probability > 0.5 else "پایین"
        
        content = f"""==================================================
سامانه هشدار زودهنگام دیپلماتیک (DEWS)
گزارش راهبردی شخصی‌سازی‌شده برای فعالان اقتصادی مرزی
==================================================

[برآورد احتمال تنش/بحران مرزی]: {forecast_probability * 100:.1f}% (سطح تنش: {risk_level})

توصیه‌های راهبردی بر اساس پروتکل مدیریت ریسک سامانه DEWS:

۱. تاجران محتاط (کالاهای سریع‌الفساد / مواد غذایی):
   - توصیه: تا اطلاع ثانوی بارگیری‌های جدید را به تعویق بیندازید.
   - مسیر جایگزین: در صورت ضرورت، بررسی مرز میلک یا سایر مبادی رسمی.

۲. تاجران با ریسک‌پذیری متوسط (مصالح ساختمانی / صنعتی):
   - توصیه: پیگیری وضعیت مجوزها و تخلیه روزانه؛ بارگیری در حجم‌های خرد.

۳. فعالان اقتصادی کلان و سرمایه‌گذاران بلندمدت:
   - توصیه: بازبینی تعهدات ارزی و قراردادهای ترانزیتی متناسب با نوسانات احتمالی.

--------------------------------------------------
این گزارش به‌طور خودکار توسط موتور استنتاج بیزی DEWS تولید شده است.
"""

        with open(output_filepath, "w", encoding="utf-8") as f:
            f.write(content)

        logger.info(f"Personalized report successfully written to {output_filepath} with risk level: {risk_level}")

    except Exception as e:
        logger.error(f"Failed to generate personalized report: {e}")
        raise
