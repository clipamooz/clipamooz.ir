from datetime import datetime
from Configuration.config import AUDIT_LOG_FILE


def append_audit_log(
    *,
    forecast_id: str,
    border_name: str,
    prior_prob: float,
    current_prob: float,
    brier_score: float,
    events_summary: list[dict],
) -> None:
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "==================================================",
        f"DEWS TECHNICAL AUDIT LOG | RUN: {forecast_id}",
        f"Timestamp: {now_str} | Target: {border_name}",
        "--------------------------------------------------",
        f"Historical Prior (Base Rate): {prior_prob:.6f} ({prior_prob:.2%})",
        "Evidence Pipeline Trace:",
    ]

    for ev in events_summary:
        lines.append(
            f"  - [{ev['event_id']}] "
            f"Raw LR: {ev['raw_lr']:.2f} | "
            f"Effective LR: {ev['effective_lr']:.2f} | "
            f"Probability After Event: {ev['prob_after']:.2%}"
        )

    lines.extend(
        [
            "--------------------------------------------------",
            f"Final Posterior Probability : {current_prob:.6f} ({current_prob:.2%})",
            f"Brier Score Evaluation      : {brier_score:.6f}",
            "==================================================\n",
        ]
    )

    with open(AUDIT_LOG_FILE, "a", encoding="utf-8") as f:
        f.write("\n".join(lines))
