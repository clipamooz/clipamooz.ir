"""
DEWS Geopolitical Vector Store
Handles indexing and semantic retrieval for border events & thesis insights.
Persists data locally in Database/vector_db/
"""

import json
import math
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
from Modules.schemas import ChunkSchema


class GeopoliticalVectorStore:

    def __init__(self, persist_dir: str = "Database/vector_db"):
        self.persist_dir = Path(persist_dir)
        self.persist_dir.mkdir(parents=True, exist_ok=True)
        self.fallback_file = self.persist_dir / "fallback_store.json"
        self.chroma_client = None
        self.collection = None

        # تلاش برای اتصال به کرومادی‌بی محلی
        try:
            import chromadb
            from chromadb.config import Settings

            self.chroma_client = chromadb.PersistentClient(
                path=str(self.persist_dir)
            )
            self.collection = self.chroma_client.get_or_create_collection(
                name="dews_geopolitical_knowledge",
                metadata={"hnsw:space": "cosine"},
            )
            self.engine_type = "chromadb"
        except Exception:
            # در صورت عدم نصب یا خطای ویندوز، بدون توقف سیستم از فال‌بک استفاده می‌شود
            self.engine_type = "lightweight_fallback"
            self._init_fallback_store()

    def _init_fallback_store(self):
        if not self.fallback_file.exists():
            with open(self.fallback_file, "w", encoding="utf-8") as f:
                json.dump([], f, ensure_ascii=False, indent=2)

    def add_chunks(self, chunks: List[ChunkSchema]):
        """ذخیره چانک‌ها همراه با متادیتا در وکتور استور"""
        if not chunks:
            return 0

        if self.engine_type == "chromadb":
            ids = [c.chunk_id for c in chunks]
            documents = [c.text for c in chunks]
            metadatas = [
                {
                    "document_id": c.document_id,
                    "source_type": c.metadata.source_type,
                    "border": c.metadata.border,
                    "conflict_type": c.metadata.conflict_type or "general",
                    "actors": ",".join(c.metadata.actors),
                    "reliability_weight": float(c.metadata.reliability_weight),
                    "published_date": c.metadata.published_date,
                }
                for c in chunks
            ]
            self.collection.upsert(
                ids=ids, documents=documents, metadatas=metadatas
            )
            return len(chunks)
        else:
            # ذخیره در فایل محلی برای فال‌بک
            with open(self.fallback_file, "r", encoding="utf-8") as f:
                current_data = json.load(f)

            for c in chunks:
                record = {
                    "chunk_id": c.chunk_id,
                    "document_id": c.document_id,
                    "text": c.text,
                    "metadata": {
                        "source_type": c.metadata.source_type,
                        "border": c.metadata.border,
                        "conflict_type": c.metadata.conflict_type or "general",
                        "actors": c.metadata.actors,
                        "reliability_weight": c.metadata.reliability_weight,
                        "published_date": c.metadata.published_date,
                    },
                }
                # حذف رکورد تکراری قبلی در صورت وجود
                current_data = [
                    x for x in current_data if x["chunk_id"] != c.chunk_id
                ]
                current_data.append(record)

            with open(self.fallback_file, "w", encoding="utf-8") as f:
                json.dump(current_data, f, ensure_ascii=False, indent=2)

            return len(chunks)

    def search_similar(
        self,
        query: str,
        n_results: int = 3,
        filter_border: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        جستجوی تجارب مشابه تاریخی بر اساس متن ورودی
        مثال: 'اعتصاب گمرکی رانندگان' -> بازیابی حوادث مشابه
        """
        if self.engine_type == "chromadb":
            where_clause = (
                {"border": filter_border} if filter_border else None
            )
            results = self.collection.query(
                query_texts=[query],
                n_results=n_results,
                where=where_clause,
            )

            hits = []
            if results and results.get("documents"):
                for i in range(len(results["documents"][0])):
                    hits.append(
                        {
                            "chunk_id": results["ids"][0][i],
                            "text": results["documents"][0][i],
                            "metadata": results["metadatas"][0][i],
                            "distance": (
                                results["distances"][0][i]
                                if "distances" in results
                                else None
                            ),
                        }
                    )
            return hits
        else:
            # موتور سبک تطابق مفهومی روی فایل فال‌بک
            with open(self.fallback_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            query_words = set(query.split())
            scored = []
            for item in data:
                if (
                    filter_border
                    and item["metadata"].get("border") != filter_border
                ):
                    continue
                item_words = set(item["text"].split())
                overlap = len(query_words.intersection(item_words))
                if overlap > 0:
                    scored.append((overlap, item))

            scored.sort(key=lambda x: x[0], reverse=True)
            return [
                {
                    "chunk_id": x[1]["chunk_id"],
                    "text": x[1]["text"],
                    "metadata": x[1]["metadata"],
                    "match_score": x[0],
                }
                for x in scored[:n_results]
            ]
