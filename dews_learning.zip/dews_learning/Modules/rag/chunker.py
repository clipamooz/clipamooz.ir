"""
DEWS Semantic Chunker for Geopolitical Documents
Splits long texts (thesis, interviews) into meaningful chunks with metadata.
"""

import hashlib
from typing import List
from Modules.schemas import ChunkSchema, GeopoliticalMetadata


class GeopoliticalChunker:
    def __init__(self, chunk_size: int = 500, overlap: int = 50):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def split_text(self, text: str) -> List[str]:
        """تقسیم متن بر اساس کاراکتر یا جملات با حفظ همپوشانی"""
        if not text:
            return []
        
        words = text.split()
        chunks = []
        for i in range(0, len(words), self.chunk_size - self.overlap):
            chunk_words = words[i:i + self.chunk_size]
            chunks.append(" ".join(chunk_words))
        return chunks

    def create_chunks(self, document_id: str, raw_text: str, metadata: GeopoliticalMetadata) -> List[ChunkSchema]:
        """تولید ساختار استاندارد ChunkSchema همراه با فراداده ژئوپلیتیک"""
        raw_chunks = self.split_text(raw_text)
        result = []
        
        for idx, chunk_text in enumerate(raw_chunks):
            hasher = hashlib.sha256(f"{document_id}_{idx}_{chunk_text[:30]}".encode('utf-8'))
            chunk_id = f"chk_{hasher.hexdigest()[:12]}"
            
            chunk_obj = ChunkSchema(
                chunk_id=chunk_id,
                document_id=document_id,
                text=chunk_text,
                metadata=metadata
            )
            result.append(chunk_obj)
            
        return result
