"""
DEWS RAG Engine
Bridges Semantic Vector Retrieval with Bayesian Forecasting.
Transforms qualitative historical precedents (thesis gold insights)
into quantitative Bayesian evidence likelihoods.
"""

from typing import Any, Dict, List, Optional
from Modules.rag.vector_store import GeopoliticalVectorStore


class RAGEngine:

    def __init__(self, vector_store: Optional[GeopoliticalVectorStore] = None):
        self.vector_store = vector_store or GeopoliticalVectorStore()

    def retrieve_context_for_event(
        self,
        event_title: str,
        border: Optional[str] = None,
        top_k: int = 2,
    ) -> List[Dict[str, Any]]:
        """بازیابی شواهد مشابه تاریخی برای یک رویداد مرزی خاص"""
        return self.vector_store.search_similar(
            query=event_title, n_results=top_k, filter_border=border
        )

    def calculate_rag_likelihood_multiplier(
        self, precedents: List[Dict[str, Any]]
    ) -> float:
        """
        تبدیل شواهد کیفی تاریخی به ضریب اثر بیزی (Likelihood Ratio Modifier)
        طبق متد Superforecasting: شواهد تاریخی نزدیک، اثر سیگنال جاری را تنظیم می‌کنند.
        """
        if not precedents:
            return 1.0  # شواهدی پیدا نشد، اثر خنثی

        # میانگین وزن اعتبار منابع بازیابی شده
        weights = []
        for p in precedents:
            meta = p.get("metadata", {})
            w = meta.get("reliability_weight", 0.7)
            # در صورتی که دیتابیس کروما فاصله اقلیدسی یا کسینوسی داده باشد
            distance = p.get("distance")
            if distance is not None:
                # هرچه فاصله کمتر باشد، شباهت و اثرگذاری بیشتر است
                similarity = max(0.1, 1.0 - distance)
                weights.append(w * similarity)
            else:
                weights.append(w)

        avg_impact = sum(weights) / len(weights)

        # نگاشت ضریب اثر: شواهد تاریخی قوی وزن سیگنال را تا ۱.۳۵ تقویت می‌کنند
        multiplier = 1.0 + (avg_impact * 0.35)
        return round(multiplier, 3)

    def enrich_forecast_with_historical_analog(
        self,
        event_title: str,
        border: str,
    ) -> Dict[str, Any]:
        """پکیج کامل RAG برای ارائه به سیستم گزارش‌دهی و موتور پیش‌بینی"""
        precedents = self.retrieve_context_for_event(
            event_title=event_title, border=border, top_k=2
        )
        multiplier = self.calculate_rag_likelihood_multiplier(precedents)

        summary_precedents = []
        for p in precedents:
            summary_precedents.append(
                {
                    "text": p["text"],
                    "conflict_type": p.get("metadata", {}).get(
                        "conflict_type", "general"
                    ),
                    "source": p.get("metadata", {}).get(
                        "source_type", "thesis"
                    ),
                }
            )

        return {
            "has_precedent": len(precedents) > 0,
            "precedents_count": len(precedents),
            "evidence_multiplier": multiplier,
            "precedents": summary_precedents,
        }
