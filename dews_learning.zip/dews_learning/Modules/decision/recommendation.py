"""موتور تحلیل ریسک و صدور توصیه‌های کاربردی برای تجار"""
from Configuration.logging_config import get_logger

logger = get_logger("DEWS.Recommendation")

def get_merchant_risk_profile(prob: float, border_name: str) -> dict:
    
    border_fa_map = {"dogharoun": "دوغارون", "milak": "میلک", "mahirood": "ماهیرود"}
    b_name = border_fa_map.get(str(border_name).lower(), border_name)

    if prob < 0.30:
        logger.info(f"Risk profile generated for {b_name}: Level GREEN (Prob: {prob:.2%})")
        return {
            "level": "سبز (ریسک پایین - تردد روان) 🟢",
            "action_title": "تردد عادی تجاری با رصد دوره‌ای",
            "advices": [
                f"۱. بارگیری و تردد به سمت مرز {b_name} بدون مانع ارزیابی می‌شود.",
                "۲. زمان توقف پیش‌بینی‌شده: کمتر از ۱۲ ساعت (روال معمول گمرکی).",
                "۳. تسویه حساب کرایه و بار بر اساس اسناد استاندارد ادامه یابد."
            ]
        }
    elif prob < 0.50:
        logger.info(f"Risk profile generated for {b_name}: Level YELLOW (Prob: {prob:.2%})")
        return {
            "level": "زرد / احتیاط (هشدار زودهنگام معطلی) 🟡",
            "action_title": "احتیاط در ارسال محموله‌های فاسدشدنی و زمان‌محور",
            "advices": [
                f"۱. از اعزام بارهای فاسدشدنی بدون کانتینر یخچالی به مرز {b_name} خودداری شود.",
                "۲. پیش‌بینی افزایش خواب کامیون بین ۲۴ تا ۴۸ ساعت پشت مرز.",
                "۳. بررسی مسیرهای جایگزین (مرز ماهیرود / فراه) برای بارهای فوری.",
                "۴. تسویه نهایی کرایه حمل تا ورود به گمرک مقصد معلق گردد."
            ]
        }
    elif prob < 0.75:
        logger.info(f"Risk profile generated for {b_name}: Level ORANGE (Prob: {prob:.2%})")
        return {
            "level": "نارنجی (ریسک بالا - احتمال انسداد نیمه‌سنگین) 🟠",
            "action_title": "توقف اعزام محموله‌های جدید و مدیریت بار بین‌راهی",
            "advices": [
                f"۱. توقف فوری بارگیری هرگونه محموله جدید به مقصد {b_name}.",
                "۲. رانندگان بین‌راهی به تیرپارک‌های ترانزیتی مشهد یا تربت‌جام هدایت شوند.",
                "۳. پیش‌بینی خواب کامیون بین ۳ تا ۵ شبانه‌روز و افزایش هزینه دپو/دموراژ.",
                "۴. فعال‌سازی فوری تغییر مسیر به مرز ماهیرود در صورت داشتن مجوز.",
                "۵. عدم تسویه ارزی تا تایید نهایی قبض انبار طرف افغانستانی."
            ]
        }
    # بخش اصلاح‌شده در Modules/recommendation.py برای ریسک قرمز (Red Level)
    else:
        logger.info(f"Risk profile generated for {b_name}: Level RED (Prob: {prob:.2%})")
        # P >= 0.75: وضعیت قرمز (بحرانی)
        advices = [
            f"⛔ توقف بلادرنگ اعزام هرگونه محموله جدید به مرز {b_name} تا تثبیت شرایط.",
            f"🔄 در صورت بارگیری، تخلیه بار در انبار یا تغییر کریدور ترانزیتی به مرز جایگزین.",
            f"📞 برقراری ارتباط اضطراری با نماینده اتاق مشترک بازرگانی و ترخیص‌کاران مقیم مرز.",
            f"⏱ پیش‌بینی زمان معطلی در نقطه صفر مرزی: بین ۷ الی ۱۸ روز کاری."
        ]
        return {
            "border": border_name,
            "level": "🔴 قرمز (بسیار بحرانی)",
            "action_title": "هشدار انسداد قطعی و دپوی محموله تجاری",
            "advices": advices
        }


