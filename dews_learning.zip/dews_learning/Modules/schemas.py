from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class GeopoliticalMetadata(BaseModel):
    """متادیتای ژئوپلیتیک و تجاری برای اسناد، اخبار و رویدادهای مرزی (مرجع: پایان‌نامه)"""
    source_type: str = Field(
        default="live_news",
        description="نوع منبع: thesis_gold, interview, live_news, customs_doc"
    )
    border: str = Field(
        default="Dogharoun",
        description="مرز هدف: Dogharoun, Milak, Mahiroud, Chabahar, General"
    )
    actors: List[str] = Field(
        default_factory=list,
        description="بازیگران کلیدی دخیل در رویداد (مثلاً گمرک، طالبان، ترانزیت‌داران)"
    )
    conflict_type: Optional[str] = Field(
        default=None,
        description="نوع تنش یا رویداد (مثلاً customs_strike, border_closure, tariff_hike)"
    )
    published_date: Optional[str] = Field(
        default=None,
        description="تاریخ انتشار یا ثبت رویداد"
    )
    reliability_weight: float = Field(
        default=0.8,
        ge=0.0,
        le=1.0,
        description="وزن اعتبار منبع (بین 0 تا 1)"
    )


# src/schemas.py
from datetime import datetime
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class ChunkSchema(BaseModel):
    """مدل داده‌ای قطعات متنی استخراج‌شده از اسناد و گزارش‌ها"""

    chunk_id: str = Field(
        ..., description="شناسه یکتا بر اساس هش محتوا یا UUID"
    )
    doc_id: str = Field(..., description="شناسه سند مرجع")
    content: str = Field(..., description="متن خالص خرد شده")
    source_type: str = Field(
        ...,
        description="نوع منبع: توافقنامه دیپلماتیک، خبر، آمار گمرکی، تعرفه",
    )
    border_crossing: Optional[str] = Field(
        None, description="نام پایانه مرزی مربوطه (دوغارون، زرنج، اسلام‌قلعه و...)"
    )
    commodity: Optional[str] = Field(
        None, description="کالای مربوطه (سوخت، آرد، صیفی‌جات و...)"
    )
    published_at: Optional[datetime] = Field(
        None, description="تاریخ انتشار سند"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="سایر متادیتاهای آزاد"
    )


class DocumentEmbedding(BaseModel):
    """مدل نگهداری بردار امبدینگ متصل به هر چانک"""

    chunk_id: str = Field(..., description="شناسه چانک متناظر")
    embedding: List[float] = Field(
        ..., description="بردار ویژگی‌های تولید شده (مثلا ۱۵۳۶ بعدی)"
    )
    model_name: str = Field(
        default="text-embedding-3-small",
        description="نام مدل مورد استفاده برای وکتورایز",
    )
    dimension: int = Field(..., description="طول بردار امبدینگ")
    created_at: datetime = Field(default_factory=datetime.utcnow)


class RetrievedEvidence(BaseModel):
    """مدل شواهد بازیابی‌شده برای تزریق به ماژول به‌روزرسانی بیزی و گزارش‌ساز"""

    chunk: ChunkSchema = Field(..., description="خود چانک بازیابی‌شده")
    similarity_score: float = Field(
        ..., ge=0.0, le=1.0, description="میزان شباهت کسینوسی به کوئری"
    )
    likelihood_ratio: float = Field(
        default=1.0,
        ge=0.0,
        description="نسبت درست‌نمایی شواهد (Likelihood Ratio) برای به‌روزرسانی بیزی بر اساس سوپرفورکستینگ",
    )
    retrieved_at: datetime = Field(default_factory=datetime.utcnow)


class EventSchema(BaseModel):
    """مدل ثبت رویداد خام دیپلماتیک و مرزی"""
    event_id: str = Field(..., description="شناسه یکتا رویداد")
    source_name: str = Field(..., description="منبع خبر یا گزارش")
    raw_text: str = Field(..., description="متن خام یا گزارش دریافتی")
    source_credibility: float = Field(default=0.7, ge=0.0, le=1.0, description="اعتبار منبع اولیه")
    timestamp: Optional[datetime] = Field(default_factory=datetime.utcnow, description="زمان ثبت رویداد")
    target_border: str = Field(default="Dogharoun", description="مرز مرتبط")


class SignalSchema(BaseModel):
    """مدل سیگنال استخراج‌شده برای تحلیل پیش‌بینی (ترکیب با نگاه بیرونی و به‌روزرسانی بیزی)"""
    signal_id: str = Field(..., description="شناسه یکتا سیگنال")
    event_id: str = Field(..., description="شناسه رویداد مرجع")
    target_border: str = Field(default="Dogharoun", description="مرز هدف")
    indicator_type: str = Field(default="general", description="نوع شاخص هشدار زودهنگام")
    likelihood_ratio: float = Field(default=1.0, gt=0.0, description="نسبت درست‌نمایی (Likelihood Ratio) برای به‌روزرسانی بیزی")
    hours_passed: float = Field(default=0.0, ge=0.0, description="زمان سپری شده از شروع رویداد")


class BaseRateSchema(BaseModel):
    """مدل نرخ پایه و کلاس مرجع (برگرفته از Superforecasting برای کالیبره کردن پیش‌بینی‌ها)"""
    rate_id: str = Field(..., description="شناسه یکتا نرخ پایه")
    category: str = Field(..., description="دسته‌بندی موضوعی (مثلاً بسته‌شدن مرز، اعتصاب گمرکی)")
    target_border: str = Field(default="Dogharoun", description="مرز هدف")
    prior_probability: float = Field(..., ge=0.0, le=1.0, description="احتمال پیشین (Prior)")
    reference_class: str = Field(..., description="توضیح کلاس مرجع تاریخی")
