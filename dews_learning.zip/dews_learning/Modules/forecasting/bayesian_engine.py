"""
DEWS Bayesian Inference Engine
ماژول تحلیل و به‌روزرسانی باورها مبتنی بر آموزه‌های Superforecasting و نیمه‌عمر داده‌ها
"""

import math
from datetime import datetime
from typing import Union


def prob_to_odds(p: float) -> float:
    """تبدیل احتمال به بخت (Odds) با جلوگیری از تقسیم بر صفر"""
    p = min(max(p, 0.001), 0.999)
    return p / (1.0 - p)


def odds_to_prob(o: float) -> float:
    """تبدیل بخت (Odds) به احتمال"""
    return o / (1.0 + o)


def update_odds(prior_odds: float, likelihood_ratio: float) -> float:
    """به‌روزرسانی بخت بیزی: Posterior Odds = Prior Odds * LR"""
    return prior_odds * likelihood_ratio


def calculate_age_in_hours(signal_time: Union[datetime, str, float, int], reference_time: datetime = None) -> float:
    """
    محاسبه امن سن سیگنال بر حسب ساعت، سازگار با انواع فرمت‌های دیتابیس (رشته، datetime یا عدد)
    """
    if isinstance(signal_time, (int, float)):
        return max(0.0, float(signal_time))

    if reference_time is None:
        reference_time = datetime.now()

    if isinstance(signal_time, str):
        # حذف Z احتمالی و هندل کردن انواع فرمت زمان
        clean_time = signal_time.replace("Z", "").strip()
        try:
            signal_time = datetime.fromisoformat(clean_time)
        except ValueError:
            try:
                signal_time = datetime.strptime(clean_time[:19], "%Y-%m-%d %H:%M:%S")
            except ValueError:
                # در صورت نامعتبر بودن فرمت، فرض را بر داده جاری می‌گذاریم
                return 0.0

    # حذف اطلاعات منطقه زمانی برای جلوگیری از خطای مقایسه
    if hasattr(signal_time, 'tzinfo') and signal_time.tzinfo is not None:
        signal_time = signal_time.replace(tzinfo=None)
    if hasattr(reference_time, 'tzinfo') and reference_time.tzinfo is not None:
        reference_time = reference_time.replace(tzinfo=None)

    diff_seconds = (reference_time - signal_time).total_seconds()
    # جلوگیری از سن منفی (در صورتی که خبر برای چند ثانیه یا دقیقه آینده ثبت شده باشد)
    return max(0.0, diff_seconds / 3600.0)


def calculate_effective_lr(
    base_lr: float = 1.0,
    reliability: float = 1.0,
    age_hours: Union[float, datetime, str] = 0.0,
    half_life_hours: float = 72.0,
    **kwargs
) -> float:
    """
    محاسبه Likelihood Ratio موثر با در نظر گرفتن اعتبار منبع و زوال زمانی (نیمه‌عمر)
    سازگار با آرگومان‌های قدیمی (raw_lr, decay_lambda, hours_passed)
    """
    # سازگاری با آرگومان‌های احتمالی ورودی پایپ‌لاین
    if 'raw_lr' in kwargs:
        base_lr = kwargs.get('raw_lr', base_lr)
    if 'hours_passed' in kwargs:
        age_hours = kwargs.get('hours_passed', age_hours)
    if 'decay_lambda' in kwargs and 'half_life_hours' not in kwargs:
        # اگر لایمبدا ارسال شده بود، تبدیل تقریبی به نیمه‌عمر: t_half = ln(2)/lambda
        lam = kwargs.get('decay_lambda', 0.0)
        half_life_hours = (math.log(2) / lam) if lam > 0 else 72.0

    # تبدیل امن سن به ساعت در صورت ارسال datetime یا رشته
    if not isinstance(age_hours, (int, float)):
        age_hours = calculate_age_in_hours(age_hours)
    else:
        age_hours = max(0.0, float(age_hours))

    # ۱. تعدیل بر اساس اعتبار منبع
    rel = min(max(reliability, 0.0), 1.0)
    lr_source_adjusted = 1.0 + (base_lr - 1.0) * rel

    # ۲. ضریب نمایی نیمه‌عمر
    if half_life_hours > 0:
        decay_factor = math.pow(0.5, age_hours / half_life_hours)
    else:
        decay_factor = 1.0

    # ۳. محاسبه LR نهایی
    effective_lr = 1.0 + (lr_source_adjusted - 1.0) * decay_factor

    return min(max(effective_lr, 0.01), 100.0)
def calculate_brier_score(forecast_prob: float, actual_outcome: int) -> float:
    """
    محاسبه امتیاز بریر (Brier Score): معیار دقت پیش‌بینی (بین 0 تا 1، کمتر یعنی بهتر)
    forecast_prob: احتمال پیش‌بینی شده توسط مدل (بین 0 و 1)
    actual_outcome: تحقق واقعی رویداد (0 یا 1)
    """
    return round((forecast_prob - float(actual_outcome)) ** 2, 4)
