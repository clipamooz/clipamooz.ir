def probability_to_odds(p):
    p = max(0.0001, min(0.9999, p))
    return p / (1.0 - p)


def odds_to_probability(odds):
    return odds / (1.0 + odds)