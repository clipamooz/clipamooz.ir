"""
DEWS (Diplomatic Early Warning System)
Module: Freshness & Exponential Decay Engine
Author: DEWS AI Core Team
"""

from datetime import datetime, timezone
from typing import Dict, Any, Optional
import math


class FreshnessDecayEngine:
    """
    موتور مدیریت زوال زمانی داده‌ها و سیگنال‌ها بر اساس نیمه‌عمر (Half-Life).
    این ماژول مانع از اثرگذاری داده‌های سوخته و منقضی در محاسبات به‌روزرسانی بیزی می‌شود.
    """

    # تنظیمات نیمه‌عمر بر حسب ساعت
    HALF_LIFE_CONFIG = {
        "border_incident": 12.0,       # درگیری، بسته شدن ناگهانی گیت یا تنش فیزیکی مرز
        "customs_strike": 24.0,        # اعتصاب گمرک، معطلی رانندگان، قطعی سامانه EPL
        "market_pulse": 48.0,          # نوسان نرخ صرافی هرات/مشهد، حواله، قیمت گازوئیل
        "diplomatic_policy": 168.0,    # موافقت‌نامه‌ها، تعرفه‌های ترجیحی، دیدار وزرا (۱ هفته)
        "default": 36.0                # مقدار پیش‌فرض در صورت نامشخص بودن دسته‌بندی
    }

    def __init__(self, custom_half_lives: Optional[Dict[str, float]] = None):
        self.half_lives = dict(self.HALF_LIFE_CONFIG)
        if custom_half_lives:
            self.half_lives.update(custom_half_lives)

    @staticmethod
    def _parse_to_utc(dt_val: Any) -> datetime:
        """
        تبدیل امن ورودی‌های زمانی مختلف به datetime آگاه از منطقه زمانی (UTC).
        """
        if isinstance(dt_val, str):
            # استانداردسازی رشته‌های تاریخ با فرمت ISO
            clean_str = dt_val.replace("Z", "+00:00")
            dt = datetime.fromisoformat(clean_str)
        elif isinstance(dt_val, datetime):
            dt = dt_val
        else:
            dt = datetime.now(timezone.utc)

        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)

    def calculate_age_hours(self, published_at: Any, reference_time: Optional[Any] = None) -> float:
        """
        محاسبه سن دقیق خبر یا رویداد بر حسب ساعت
        """
        pub_dt = self._parse_to_utc(published_at)
        ref_dt = self._parse_to_utc(reference_time) if reference_time else datetime.now(timezone.utc)
        
        diff = (ref_dt - pub_dt).total_seconds()
        return max(0.0, diff / 3600.0)

    def calculate_decay_weight(self, age_hours: float, category: str = "default") -> float:
        """
        محاسبه ضریب زوال بین 0.0 تا 1.0 با فرمول نمایی نیمه‌عمر:
        Weight = 0.5 ^ (Age / HalfLife)
        """
        half_life = self.half_lives.get(category, self.half_lives["default"])
        if half_life <= 0:
            return 1.0
        
        weight = math.pow(0.5, age_hours / half_life)
        return max(0.0, min(1.0, weight))

    def compute_effective_lr(self, base_lr: float, decay_weight: float, source_credibility: float = 1.0) -> float:
        """
        محاسبه نسبت درست‌نمایی مؤثر (Effective Likelihood Ratio).
        با گذشت زمان یا افت اعتبار منبع، LR به سمت ۱ (خنثی) میل می‌کند.
        """
        # ضریب کلی اعمال اثر = زوال زمانی * اعتبار منبع
        total_impact_factor = decay_weight * max(0.0, min(1.0, source_credibility))
        
        # فرمول بازگشت به مقدار خنثی:
        # اگر LR=3 و اثر=0.5 باشد -> LR_effective = 1 + 2*0.5 = 2.0
        # اگر LR=0.2 و اثر=0.5 باشد -> LR_effective = 1 + (-0.8)*0.5 = 0.6
        effective_lr = 1.0 + (base_lr - 1.0) * total_impact_factor
        return round(effective_lr, 4)

    def assess_signal(
        self,
        published_at: Any,
        base_lr: float,
        category: str = "default",
        source_credibility: float = 1.0,
        reference_time: Optional[Any] = None
    ) -> Dict[str, Any]:
        """
        ارزیابی کامل یک سیگنال ورودی و تحویل پکیج آماده برای پایپ‌لاین بیزی
        """
        age_hours = self.calculate_age_hours(published_at, reference_time)
        half_life = self.half_lives.get(category, self.half_lives["default"])
        decay_weight = self.calculate_decay_weight(age_hours, category)
        effective_lr = self.compute_effective_lr(base_lr, decay_weight, source_credibility)

        # تعیین وضعیت تازگی
        if age_hours <= half_life:
            status = "FRESH"
        elif age_hours <= (half_life * 3.0):
            status = "DECAYING"
        else:
            status = "STALE"  # داده سوخته و منقضی

        return {
            "age_hours": round(age_hours, 2),
            "half_life_hours": half_life,
            "decay_weight": round(decay_weight, 4),
            "source_credibility": round(source_credibility, 2),
            "base_lr": base_lr,
            "effective_lr": effective_lr,
            "status": status,
            "is_ignorable": (status == "STALE" and abs(effective_lr - 1.0) < 0.05)
        }
