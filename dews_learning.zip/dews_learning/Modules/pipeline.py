import sys
import os
from datetime import datetime, timedelta
import logging

# تنظیم مسیر ریشه پروژه
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from Database.database import DatabaseManager
from Configuration.config import HISTORICAL_BASE_RATE, AUDIT_LOG_FILE, PERSONALIZED_REPORT_FILE
from Configuration.logging_config import get_logger
from Modules.forecasting.bayesian_engine import update_odds
from Modules.freshness.decay_engine import FreshnessDecayEngine
from Modules.reporting.merchant_report import write_merchant_report

logger = get_logger("DEWS_Pipeline")

def detect_event_type(indicator: str, text: str) -> str:
    """تشخیص نوع رویداد و کلاس نیمه‌عمر بر اساس کلیدواژه‌ها"""
    text_lower = text.lower()
    if "درگیری" in text_lower or "مرز" in text_lower or "conflict" in text_lower:
        return "border_incident"
    elif "گمرک" in text_lower or "اعتصاب" in text_lower or "ترخیص" in text_lower:
        return "customs_strike"
    elif "نرخ" in text_lower or "ارز" in text_lower or "بازار" in text_lower:
        return "market_pulse"
    elif "سیاست" in text_lower or "دیپلماسی" in text_lower or "توافق" in text_lower:
        return "diplomatic_policy"
    return "default"

def fetch_events_from_db():
    """واکشی رویدادها از دیتابیس مرکزی DEWS"""
    db_path = os.path.join(os.path.dirname(__file__), '..', 'Database', 'dews_core.db')
    import sqlite3
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT event_id, source, text, indicator, timestamp FROM events ORDER BY timestamp DESC LIMIT 10")
        rows = cursor.fetchall()
        conn.close()
        return rows
    except Exception as e:
        logger.error(f"خطا در خواندن رویدادها از دیتابیس: {e}")
        return []

def run_pipeline() -> None:
    """تابع اصلی اجرای پایپ‌لاین هوشمند DEWS"""
    logger.info("🚀 شروع اجرای پایپ‌لاین هوشمند DEWS...")
    
    db = DatabaseManager()
    questions = db.get_active_warning_questions()
    
    if not questions:
        logger.warning("⚠️ هیچ سوال هشدار فعالی در پایگاه داده یافت نشد.")
        return

    freshness_engine = FreshnessDecayEngine()

    for q in questions:
        # پشتیبانی همزمان از تاپل (SQLite) و دیکشنری
        if isinstance(q, dict):
            q_id = q.get("id") or q.get("question_id", "Q_UNKNOWN")
            q_text = q.get("text") or q.get("question_text", "سوال بدون عنوان")
            target_entity = q.get("target_entity", "شیرخان_بندر")
            raw_prob = q.get("current_prob", 0.5)
            raw_base = q.get("base_rate", 0.5)
        else:
            # حالت تاپل بر اساس ترتیب ستون‌های جدول دیتابیس
            q_id = q[0] if len(q) > 0 else "Q_UNKNOWN"
            q_text = q[1] if len(q) > 1 else "سوال بدون عنوان"
            target_entity = q[2] if len(q) > 2 else "شیرخان_بندر"
            raw_prob = q[3] if len(q) > 3 else 0.5
            raw_base = q[4] if len(q) > 4 else 0.5

        try:
            current_prob = float(raw_prob)
            base_rate = float(raw_base)
        except (ValueError, TypeError):
            current_prob = 0.5
            base_rate = 0.5

        logger.info(f"الگوی پایش برای سوال [{q_id}]: {q_text} (احتمال فعلی: {current_prob})")

        # رویدادهای شبیه‌سازی‌شده یا واقعی مرزی
        mock_events = [
            {"indicator": target_entity, "text": f"تحولات مرزی در حوزه {target_entity}", "raw_lr": 1.25, "reliability": 0.9, "hours_ago": 4},
            {"indicator": target_entity, "text": f"گزارش ثانویه بازار {target_entity}", "raw_lr": 1.15, "reliability": 0.8, "hours_ago": 24}
        ]

        current_odds = current_prob / (1 - current_prob) if current_prob < 1 else 999.0

        for ev in mock_events:
            event_type = detect_event_type(ev["indicator"], ev["text"])
            half_life_map = {
                "border_incident": 12,
                "customs_strike": 24,
                "market_pulse": 48,
                "diplomatic_policy": 72,
                "default": 36
            }
            half_life = half_life_map.get(event_type, 36)

            # محاسبات زوال زمان و وزن رویداد
            decay_factor = 0.5 ** (ev["hours_ago"] / half_life)
            total_weight = decay_factor * ev["reliability"]
            effective_lr = 1 + (ev["raw_lr"] - 1) * total_weight
            current_odds = update_odds(current_odds, effective_lr)

            # فراخوانی گزارش‌ساز بازرگان با شواهد RAG و به‌روزرسانی نهایی
            write_merchant_report(current_prob)
            final_prob = current_odds / (1 + current_odds)
            logger.info(f"🎯 احتمال به‌روزرسانی‌شده برای سوال [{q_id}]: {final_prob:.4f}")



if __name__ == "__main__":
    run_pipeline()
