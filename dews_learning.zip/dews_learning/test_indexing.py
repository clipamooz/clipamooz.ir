# test_index_pipeline.py
from datetime import datetime
from src.schemas import ChunkSchema, DocumentEmbedding, RetrievedEvidence


def run_pipeline_test():
    # ۱. تعریف یک نمونه چانک مرزی (اسلام‌قلعه / تانکر سوخت)
    sample_chunk = ChunkSchema(
        chunk_id="chk_001_dogharoun",
        doc_id="doc_ir_afg_2026_04",
        content="طرف افغانستانی اعلام کرد از روز دوشنبه پذیرش تانکرهای سوخت در دوغارون به دلیل نقص در اسناد استاندارد متوقف خواهد شد.",
        source_type="بیانیه رسمی گمرک",
        border_crossing="دوغارون",
        commodity="سوخت و فرآورده‌های نفتی",
        published_at=datetime.now(),
        metadata={"urgency": "high", "risk_level": "critical"},
    )

    # ۲. ایجاد امبدینگ ساختگی (Dummy Embedding)
    sample_embedding = DocumentEmbedding(
        chunk_id=sample_chunk.chunk_id,
        embedding=[0.012, 0.941, -0.223, 0.451],
        model_name="mock-embedding-v1",
        dimension=4,
    )

    # ۳. بازیابی به عنوان شاهد با وزن بیزی
    evidence = RetrievedEvidence(
        chunk=sample_chunk,
        similarity_score=0.89,
        likelihood_ratio=3.5,  # شواهد قوی به نفع بسته شدن مرز
    )

    # ۴. تولید خروجی گزارش بازرگان (merchant_report.txt)
    merchant_output = (
        f"=== گزارش هشدار زودهنگام تجاری (DEWS) ===\n"
        f"پایانه هدف: {evidence.chunk.border_crossing}\n"
        f"کالا: {evidence.chunk.commodity}\n"
        f"شدت هشدار: {evidence.chunk.metadata.get('risk_level')}\n"
        f"خلاصه شواهد: {evidence.chunk.content}\n"
        f"وزن شواهد در مدل بیزی (LR): {evidence.likelihood_ratio}\n"
        f"امتیاز انطباق: {evidence.similarity_score * 100:.1f}%\n"
        f"تاریخ ثبت: {evidence.retrieved_at.strftime('%Y-%m-%d %H:%M')}\n"
    )

    with open("merchant_report.txt", "w", encoding="utf-8") as f:
        f.write(merchant_output)

    # ۵. تولید گزارش شخصی‌سازی‌شده تجار (personalized_reports.txt)
    personalized_output = (
        f"--- گزارش اختصاصی تاجر (پروفایل: صادرات هیدروکربن به هرات) ---\n"
        f"شناسه سند مبنا: {evidence.chunk.doc_id}\n"
        f"توصیه عملیاتی: توقف اعزام ناوگان جدید تا رفع ابهام استاندارد.\n"
        f"نرخ احتمال توقف مرز (پس از اعمال شواهد): با توجه به LR={evidence.likelihood_ratio}، احتمال وقوع ریسک بالاست.\n"
    )

    with open("personalized_reports.txt", "w", encoding="utf-8") as f:
        f.write(personalized_output)

    print(
        "✅ تست با موفقیت اجرا شد و هر دو فایل گزارش با داده‌های واقعی ساخته شدند!"
    )


if __name__ == "__main__":
    run_pipeline_test()
