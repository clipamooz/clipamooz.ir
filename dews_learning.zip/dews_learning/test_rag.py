"""
تست جامع RAG Engine: اتصال حافظه تاریخی به تصمیم‌گیری زودهنگام
"""

from Modules.rag.rag_engine import RAGEngine


def run_rag_engine_test():
    print("🧠 شروع ارزیابی RAG Engine در تعامل با حافظه تاریخی...")

    rag = RAGEngine()

    # شبیه‌سازی یک رویداد جدید گمرکی که همین امروز رخ داده
    current_live_event = "بخشنامه ارزی جدید طالبان و ایجاد صف تانکرها در هرات"
    target_border = "Dogharoun"

    print(f"\n📡 رویداد رصد شده: {current_live_event}")
    print(f"📍 مرز هدف: {target_border}")

    # پردازش در موتور RAG
    enrichment = rag.enrich_forecast_with_historical_analog(
        event_title=current_live_event, border=target_border
    )

    print("\n================= نتایج تحلیل هوشمند RAG =================")
    print(f"آیا سابقه تاریخی مشابه کشف شد؟ {enrichment['has_precedent']}")
    print(f"تعداد شواهد منطبق: {enrichment['precedents_count']}")
    print(f"ضریب تقویت شواهد بیزی: {enrichment['evidence_multiplier']}x")

    print("\n📜 شواهد بازیابی شده از گنجینه تجربی پایان‌نامه:")
    for idx, prec in enumerate(enrichment["precedents"], start=1):
        print(f"  {idx}. [نوع بحران: {prec['conflict_type']}]")
        print(f"     متن سابقه: {prec['text']}")
    print("===========================================================")


if __name__ == "__main__":
    run_rag_engine_test()
