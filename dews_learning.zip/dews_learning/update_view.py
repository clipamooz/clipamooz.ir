import sqlite3
import os

os.makedirs('Outputs', exist_ok=True)
conn = sqlite3.connect('Database/dews_core.db')
c = conn.cursor()
c.execute('SELECT id, category, target_entity, question_text, time_horizon_days, base_rate, current_probability, created_at, expires_at, status FROM warning_questions')
rows = c.fetchall()
conn.close()

with open('Outputs/db_questions_view.txt', 'w', encoding='utf-8') as f:
    for r in rows:
        f.write(f'شناسه (ID): {r[0]}\n')
        f.write(f'خوشه: {r[1]}\n')
        f.write(f'موجودیت هدف: {r[2]}\n')
        f.write(f'متن پرسش: {r[3]}\n')
        f.write(f'افق زمانی: {r[4]} روز\n')
        f.write(f'نرخ پایه: {r[5]}\n')
        f.write(f'احتمال فعلی: {r[6]}\n')
        f.write(f'تاریخ ایجاد: {r[7]}\n')
        f.write(f'تاریخ انقضا: {r[8]}\n')
        f.write(f'وضعیت: {r[9]}\n')
        f.write('='*50 + '\n\n')

print('Outputs/db_questions_view.txt successfully refreshed!')
