import os
import sys

# تنظیم مسیر پروژه
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Modules.pipeline import run_pipeline

if __name__ == "__main__":
    print("🚀 Executing the DEWS smart pipeline...")
    run_pipeline()
    print("✅ The pipeline executed with complete success..")
