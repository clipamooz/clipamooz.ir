import math
import os
import sqlite3
from datetime import datetime

# ==========================================
# تنظیمات، پایگاه داده و فایل‌ها
# ==========================================
DB_NAME = "dews_core.db"
MERCHANT_REPORT_FILE = "merchant_report.txt"
AUDIT_LOG_FILE = "system_audit_log.txt"
TARGET_BOUNDARY = "دوغارون / اسلام‌قلعه"
HYPOTHESIS = "انسداد یا توقف موقت مرز دوغارون ظرف ۴۸ ساعت آینده"
HISTORICAL_BASE_RATE = 0.20  # نرخ پایه ۲۰٪ بر اساس پایان‌نامه (Outside View)


# ==========================================
# ۱. توابع محاسباتی بیزی و افت زمانی (Decay)
# ==========================================
def prob_to_odds(p: float) -> float:
    return p / (1.0 - p)


def odds_to_prob(o: float) -> float:
    return o / (1.0 + o)


def calculate_effective_lr(
    raw_lr: float, credibility: float, hours_elapsed: float
) -> float:
    """محاسبه وزن واقعی سیگنال با اعمال وثوق منبع و افت زمانی"""
    # اثر ضریب اطمینان منبع
    adjusted_lr = 1.0 + credibility * (raw_lr - 1.0)
    # زوال زمانی: هر چه بگذرد اثر به سمت ۱ میل می‌کند
    decay_rate = 0.03
    decay_factor = math.exp(-decay_rate * hours_elapsed)
    effective_lr = 1.0 + (adjusted_lr - 1.0) * decay_factor
    return max(0.1, effective_lr)


# ==========================================
# ۲. موتور تصمیم‌یار بازرگان (توصیه‌های میدانی)
# ==========================================
def generate_merchant_recommendations(prob: float, border_name: str) -> dict:
    """تبدیل خروجی احتمالاتی بیزی به دستورالعمل عملیاتی تاجر"""
    if prob < 0.30:
        level = "🟢 سبز (ریسک پایین - تردد روان)"
        action_title = "تردد عادی تجاری با رصد دوره‌ای"
        advices = [
            f"۱. بارگیری و تردد به سمت مرز {border_name} بدون مانع ارزیابی می‌شود.",
            "۲. زمان توقف پیش‌بینی‌شده: کمتر از ۱۲ ساعت (روال معمول گمرکی).",
            "۳. تسویه حساب کرایه و بار بر اساس اسناد استاندارد ادامه یابد.",
        ]
    elif prob < 0.50:
        level = "🟡 زرد / احتیاط (هشدار زودهنگام معطلی)"
        action_title = "احتیاط در ارسال محموله‌های فاسدشدنی و زمان‌محور"
        advices = [
            f"۱. از اعزام بارهای فاسدشدنی بدون کانتینر یخچالی به مرز {border_name} خودداری شود.",
            "۲. پیش‌بینی افزایش خواب کامیون بین ۲۴ تا ۴۸ ساعت پشت مرز.",
            "۳. بررسی مسیرهای جایگزین (مرز ماهیرود / فراه) برای بارهای فوری.",
            "۴. تسویه نهایی کرایه حمل تا ورود به گمرک مقصد معلق گردد.",
        ]
    elif prob < 0.75:
        level = "🟠 نارنجی (ریسک بالا - احتمال انسداد نیمه‌سنگین)"
        action_title = "توقف اعزام محموله‌های جدید و مدیریت بار بین‌راهی"
        advices = [
            f"۱. توقف فوری بارگیری هرگونه محموله جدید به مقصد {border_name}.",
            "۲. رانندگان بین‌راهی به تیرپارک‌های ترانزیتی مشهد یا تربت‌جام هدایت شوند.",
            "۳. پیش‌بینی خواب کامیون بین ۳ تا ۵ شبانه‌روز و افزایش هزینه دموراژ.",
            "۴. فعال‌سازی فوری تغییر مسیر به مرز ماهیرود در صورت داشتن مجوز.",
            "۵. عدم تسویه ارزی تا تایید نهایی قبض انبار طرف افغانستانی.",
        ]
    else:
        level = "🔴 قرمز (بحران قطعی - انسداد کامل مرز)"
        action_title = "انسداد کامل گذرگاه مرزی؛ لغو ارسال بار"
        advices = [
            f"۱. گذرگاه {border_name} در وضعیت بحرانی است؛ از هرگونه ارسال بار اکیداً خودداری شود.",
            "۲. کامیون‌های متوقف سریعاً به پارکینگ‌های عقبه هدایت شوند.",
            "۳. پیگیری رسمی از طریق اتاق تجارت مشترک جهت رفع گره مرزی.",
            "۴. ثبت رسمی صورت‌جلسه فورس‌ماژور جهت معافیت از جریمه دیرکرد.",
        ]

    return {"risk_level": level, "action_title": action_title, "advices": advices}


# ==========================================
# ۳. زنجیره رویدادهای زنده/شبیه‌سازی‌شده (Sequential Stream)
# ==========================================
stream_events = [
    {
        "event_id": "EVT-2026-10-001",
        "signal_id": "SIG-2026-10-001",
        "source": "کانال فعالان اقتصادی هرات",
        "credibility": 0.85,
        "payload": "توقف پذیرش کامیون‌های تجاری در گمرک اسلام‌قلعه و صف سنگین",
        "indicator_type": "توقف گمرکی و لجستیکی",
        "raw_lr": 3.50,
        "hours_elapsed": 4.0,
    },
    {
        "event_id": "EVT-2026-10-002",
        "signal_id": "SIG-2026-10-002",
        "source": "پنجره واحد تجارت فرامرزی (CSW)",
        "credibility": 0.95,
        "payload": "خطای ۵۰۳ و قطعی زیرسامانه صدور بیجک در مرز دوغارون",
        "indicator_type": "قطعی سامانه EPL",
        "raw_lr": 2.80,
        "hours_elapsed": 1.5,
    },
    {
        "event_id": "EVT-2026-10-003",
        "signal_id": "SIG-2026-10-003",
        "source": "گروه رانندگان ترانزیت تایباد",
        "credibility": 0.70,
        "payload": "اعلام بازگشایی ۲ گیت اضطراری و آغاز تخلیه بار کانتینری",
        "indicator_type": "سیگنال آرام‌بخش میدانی",
        "raw_lr": 0.40,
        "hours_elapsed": 0.5,
    },
]


# ==========================================
# ۴. اجرای چرخه کامل DEWS
# ==========================================
def run_dews_complete_pipeline():
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # اتصال به دیتابیس
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()

    current_prob = HISTORICAL_BASE_RATE
    current_odds = prob_to_odds(current_prob)

    audit_steps_text = []

    for step, evt in enumerate(stream_events, start=1):
        eff_lr = calculate_effective_lr(
            raw_lr=evt["raw_lr"],
            credibility=evt["credibility"],
            hours_elapsed=evt["hours_elapsed"],
        )

        prev_prob = current_prob
        current_odds = current_odds * eff_lr
        current_prob = odds_to_prob(current_odds)

        # ثبت در جدول رویدادها
        cur.execute(
            """
            INSERT OR REPLACE INTO events
            (event_id, source_name, raw_text, source_credibility, timestamp)
            VALUES (?, ?, ?, ?, ?)
        """,
            (
                evt["event_id"],
                evt["source"],
                evt["payload"],
                evt["credibility"],
                now_str,
            ),
        )

        # ثبت در جدول سیگنال‌ها
        cur.execute(
            """
            INSERT OR REPLACE INTO signals
            (signal_id, event_id, target_boundary, indicator_type, likelihood_ratio, hours_passed)
            VALUES (?, ?, ?, ?, ?, ?)
        """,
            (
                evt["signal_id"],
                evt["event_id"],
                TARGET_BOUNDARY,
                evt["indicator_type"],
                evt["raw_lr"],
                evt["hours_elapsed"],
            ),
        )

        # متن گزارش ممیزی برای این مرحله
        step_log = f"""--- [مرحله {step}] رویداد ورودی: {evt['event_id']} ---
• منبع: {evt['source']} (وثوق: {int(evt['credibility'] * 100)}%)
• شرح خبر: {evt['payload']}
• شاخص: {evt['indicator_type']}
• وزن خام (LR): {evt['raw_lr']:.2f} | تاخیر زمانی: {evt['hours_elapsed']} ساعت ==> وزن موثر: {eff_lr:.2f}
• به‌روزرسانی احتمال: {prev_prob * 100:.2f}%  ==>  {current_prob * 100:.2f}%
"""
        audit_steps_text.append(step_log)

    # سنجش نهایی (ارزیابی با پیامد فرضی بحران = 1)
    ground_truth = 1
    brier_score = (current_prob - ground_truth) ** 2
    final_forecast_id = f"FCT-{datetime.now().strftime('%Y%m%d%H%M')}"

    # ثبت آخرین پیش‌بینی در جدول پیش‌بینی‌ها
    cur.execute(
        """
        INSERT OR REPLACE INTO forecasts
        (forecast_id, signal_id, hypothesis, base_rate_prior,
         posterior_probability, actual_outcome, brier_score, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """,
        (
            final_forecast_id,
            stream_events[-1]["signal_id"],
            HYPOTHESIS,
            HISTORICAL_BASE_RATE,
            round(current_prob, 4),
            ground_truth,
            round(brier_score, 4),
            now_str,
        ),
    )

    conn.commit()
    conn.close()

    # ==========================================================
    # تولید فایل ۱: گزارش اختصاصی تاجر (Merchant Action Report)
    # ==========================================================
    rec = generate_merchant_recommendations(current_prob, TARGET_BOUNDARY)
    advices_formatted = "\n".join(rec["advices"])

    merchant_content = f"""======================================================================
               سامانه هشدار زودهنگام مرزی (DEWS)
           گزارش اختصاصی تصمیم‌یار تجاری — {TARGET_BOUNDARY}
======================================================================
تاریخ و ساعت صدور: {now_str}
سطح ریسک کنونی:    {rec['risk_level']}
اقدام پیشنهادی:    {rec['action_title']}
احتمال تایید بحران: {current_prob * 100:.1f}% (برآورد زنجیره‌ای از ۳ رویداد اخیر)
----------------------------------------------------------------------

📌 خلاصه‌ی وضعیت میدانی:
  • نرخ پایه تاریخی مرز: {int(HISTORICAL_BASE_RATE * 100)}%
  • آخرین سیگنال دریافتی: {stream_events[-1]['payload']}
  • اثر ترکیبی رویدادها: ریسک با قطعی فنی بالا رفت و با بازگشایی گیت‌ها تعدیل شد.

💡 توصیه‌های فوری عملیاتی و مالی:
----------------------------------------------------------------------
{advices_formatted}

======================================================================
* این گزارش توسط موتور تصمیم‌یار DEWS برای کاهش خسارت دموراژ صادر شده است.
======================================================================
"""
    with open(MERCHANT_REPORT_FILE, "w", encoding="utf-8") as f:
        f.write(merchant_content)

    # ==========================================================
    # تولید فایل ۲: لاگ مهندسی و اعتبارسنجی (System Audit Log)
    # ==========================================================
    audit_header = f"""======================================================================
               DEWS ENGINE - SYSTEM AUDIT & SEQUENTIAL LOG
======================================================================
Timestamp:         {now_str}
Database:          {DB_NAME}
Target Geography:  {TARGET_BOUNDARY}
Hypothesis:        {HYPOTHESIS}
Outside Base Rate: {HISTORICAL_BASE_RATE * 100:.2f}%
----------------------------------------------------------------------
"""
    audit_steps_joined = "\n".join(audit_steps_text)
    audit_footer = f"""======================================================================
               CALIBRATION & BRIER METRICS
======================================================================
Final Probability:     {current_prob * 100:.2f}%
Ground Truth Outcome:  {ground_truth} (Crisis Occurred)
Brier Score:           {brier_score:.4f} (Ideal calibration <= 0.25)
DB Sync:               All events, signals, and forecasts committed.
======================================================================
"""
    full_audit = audit_header + "\n" + audit_steps_joined + "\n" + audit_footer
    with open(AUDIT_LOG_FILE, "w", encoding="utf-8") as f:
        f.write(full_audit)

    print("🚀 چرخه زنجیره‌ای با موفقیت کامل اجرا شد!")
    print(f"📁 گزارش تاجر: {MERCHANT_REPORT_FILE}")
    print(f"📁 لاگ مهندسی بیزی: {AUDIT_LOG_FILE}")


if __name__ == "__main__":
    run_dews_complete_pipeline()
